//
//  HomeViewController.swift
//  NoUnwindTest
//
//  Created by Joe Keeley on 6/1/16.
//  Copyright © 2016 MartianCraft, LLC. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    override func shouldPerformSegueWithIdentifier(identifier: String, sender: AnyObject?) -> Bool {
        if identifier == "showLogin" {
            return true
        }
        return true
    }
    
    @IBAction func unwindWithNewAccountCancel(segue:UIStoryboardSegue) {
        
    }

    @IBAction func unwindLoginCancel(segue:UIStoryboardSegue) {
        
    }

}
