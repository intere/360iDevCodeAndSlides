//
//  SearchBarViewController.swift
//  Pro Storyboard Techniques
//
//  Created by Joe Keeley on 8/9/16.
//  Copyright © 2016 Joe Keeley. All rights reserved.
//

import UIKit

class SearchBarViewController: UIViewController {

    @IBOutlet weak var customSearchBar:CustomSearchBar!
    var showButtonVisible = false
    
    override func viewDidAppear(animated: Bool) {
        customSearchBar?.setDefaultSearchBarState()
    }
    
    @IBAction func toggleShowButtonTapped(sender:UIButton) {
        showButtonVisible = !showButtonVisible
        customSearchBar.setShowButtonDisplayState(showButtonVisible)
    }
    
}
