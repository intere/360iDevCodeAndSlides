//
//  CustomSearchBar.swift
//  Pro Storyboard Techniques
//
//  Created by Joe Keeley on 8/9/16.
//  Copyright © 2016 Joe Keeley. All rights reserved.
//

import UIKit

class CustomSearchBar: UIView, UITextFieldDelegate {

    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var searchShowButton: UIButton!
    @IBOutlet var cancelToSearchLeadingConstraint: NSLayoutConstraint!
    @IBOutlet var searchToShowTrailingConstraint: NSLayoutConstraint!

    func setDefaultSearchBarState() {
        cancelButton.hidden = true
        cancelToSearchLeadingConstraint.active = false
        searchShowButton.hidden = true
        searchToShowTrailingConstraint.active = false
        searchTextField.text = ""
        searchTextField.resignFirstResponder()
        UIView.animateWithDuration(0.1) {
            self.layoutIfNeeded()
        }
    }
    
    func setShowButtonDisplayState(showing:Bool) {
        searchShowButton.hidden = !showing
        searchToShowTrailingConstraint.active = showing
        UIView.animateWithDuration(0.1) {
            self.layoutIfNeeded()
        }
    }
    
    @IBAction func cancelButtonTapped(sender: UIButton) {
        setDefaultSearchBarState()
    }
        
    // MARK: Text field delegate methods
    
    func textFieldDidBeginEditing(textField: UITextField) {
        cancelToSearchLeadingConstraint.active = true
        cancelButton.hidden = false
        self.layoutIfNeeded()
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        cancelToSearchLeadingConstraint.active = false
        cancelButton.hidden = true
    }

}
