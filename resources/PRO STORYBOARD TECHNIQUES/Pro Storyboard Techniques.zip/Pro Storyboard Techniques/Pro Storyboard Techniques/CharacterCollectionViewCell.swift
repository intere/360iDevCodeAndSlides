//
//  CharacterCollectionViewCell.swift
//  Pro Storyboard Techniques
//
//  Created by Joe Keeley on 8/21/16.
//  Copyright © 2016 Joe Keeley. All rights reserved.
//

import UIKit

enum CharacterCollectionViewCellType:String {
    case Letter = "letterCell"
    case Number = "numberCell"
    case Emoji = "emojiCell"
}

class CharacterCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var characterLabel: UILabel!

}
