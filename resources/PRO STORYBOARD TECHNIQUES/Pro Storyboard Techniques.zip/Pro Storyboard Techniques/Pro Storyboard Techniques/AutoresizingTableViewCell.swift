//
//  AutoresizingTableViewCell.swift
//  Pro Storyboard Techniques
//
//  Created by Joe Keeley on 8/10/16.
//  Copyright © 2016 Joe Keeley. All rights reserved.
//

import UIKit

class AutoresizingTableViewCell: UITableViewCell {

   @IBOutlet weak var customTextLabel: UILabel!
    
}
