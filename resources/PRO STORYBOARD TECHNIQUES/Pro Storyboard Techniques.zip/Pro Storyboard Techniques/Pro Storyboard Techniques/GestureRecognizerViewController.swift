//
//  GestureRecognizerViewController.swift
//  Pro Storyboard Techniques
//
//  Created by Joe Keeley on 8/22/16.
//  Copyright © 2016 Joe Keeley. All rights reserved.
//

import UIKit

class GestureRecognizerViewController: UIViewController {

    @IBAction func tapReceived(sender: UITapGestureRecognizer) {
        print("Tap Received")
    }

}
