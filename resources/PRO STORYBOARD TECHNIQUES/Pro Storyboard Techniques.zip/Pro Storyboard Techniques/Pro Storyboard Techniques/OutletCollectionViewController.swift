//
//  OutletCollectionViewController.swift
//  Pro Storyboard Techniques
//
//  Created by Joe Keeley on 8/9/16.
//  Copyright © 2016 Joe Keeley. All rights reserved.
//

import UIKit

class OutletCollectionViewController: UIViewController {

    @IBOutlet var revenueLabels: [UILabel]!
    
    override func viewDidAppear(animated: Bool) {
        makeFontSizeUniformForLabels(revenueLabels)
    }
    
    func makeFontSizeUniformForLabels(labels:[UILabel]) {
        var maxNumberOfCharacters:Int = 0
        for label in labels {
            if let numberOfCharacters:Int = label.text?.characters.count where
                numberOfCharacters > maxNumberOfCharacters {
                maxNumberOfCharacters = numberOfCharacters
            }
        }
        
        var newFontSize:CGFloat = 15.0
        switch maxNumberOfCharacters {
        case 0..<10:
            newFontSize = 15.0
        case 10..<12:
            newFontSize = 13.0
        default:
            newFontSize = 11.0
        }
        
        let newFont = UIFont.systemFontOfSize(newFontSize)
        for label in revenueLabels {
            label.font = newFont
        }
    }
}
