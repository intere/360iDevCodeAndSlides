//
//  CharacterHeaderFooterReusableView.swift
//  Pro Storyboard Techniques
//
//  Created by Joe Keeley on 8/21/16.
//  Copyright © 2016 Joe Keeley. All rights reserved.
//

import UIKit

enum CharacterHeaderFooterResuableViewType:String {
    case Header = "sectionHeader"
    case Footer = "sectionFooter"
}

class CharacterHeaderFooterReusableView: UICollectionReusableView {
    
    @IBOutlet weak var titleLabel: UILabel!

}
