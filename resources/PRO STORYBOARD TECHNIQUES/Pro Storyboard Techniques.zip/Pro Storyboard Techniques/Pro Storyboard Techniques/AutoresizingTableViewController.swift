//
//  AutoresizingTableViewController.swift
//  Pro Storyboard Techniques
//
//  Created by Joe Keeley on 8/10/16.
//  Copyright © 2016 Joe Keeley. All rights reserved.
//

import UIKit

class AutoresizingTableViewController: UITableViewController {

    let testStrings = ["Test.",
                        "This is a test.",
                        "This is a longer test.",
                        "This is an even longer test, does it wrap?",
                        "This is yet another long test, it should definitely be wrapping",
                        "And if this test doesn't wrap, the heck if I know how long a string needs to be to make it wrap, cuz ugh."]
    
    // MARK: - Table view data source

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return testStrings.count
    }

    override func tableView(tableView: UITableView, estimatedHeightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 74.0
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCellWithIdentifier("testCell", forIndexPath: indexPath) as? AutoresizingTableViewCell else {
            return UITableViewCell()
        }

        cell.customTextLabel.text = testStrings[indexPath.row]

        return cell
    }
    

}
