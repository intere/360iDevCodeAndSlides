//
//  CollectionViewController.swift
//  Pro Storyboard Techniques
//
//  Created by Joe Keeley on 8/21/16.
//  Copyright © 2016 Joe Keeley. All rights reserved.
//

import UIKit

class CollectionViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {

    let sectionTitles = ["Letters", "Numbers", "Emoji"]
    let letters = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
    let numbers = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
    let emoji = ["👍", "👏", "👌", "😜", "😱", "😃", "😡", "😍", "🤑", "🤓", "😎", "😈", "👻", "🤘", "🐶", "🐸", "🐼", "🦄", "🐟", "🎃"]
    
    
    @IBOutlet weak var characterCollectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 3
    }
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch section {
        case 0:
            return letters.count
        case 1:
            return numbers.count
        case 2:
            return emoji.count
        default:
            return 0
        }
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        var cellIdentifier:String = ""
        var dataArray:[String] = []

        switch indexPath.section {
        case 0:
            cellIdentifier = CharacterCollectionViewCellType.Letter.rawValue
            dataArray = letters
        case 1:
            cellIdentifier = CharacterCollectionViewCellType.Number.rawValue
            dataArray = numbers
        case 2:
            cellIdentifier = CharacterCollectionViewCellType.Emoji.rawValue
            dataArray = emoji
        default:
            break
        }
        
        guard let cell = collectionView.dequeueReusableCellWithReuseIdentifier(cellIdentifier, forIndexPath: indexPath) as? CharacterCollectionViewCell else {
            return UICollectionViewCell()
        }
        
        cell.characterLabel.text = dataArray[indexPath.row]
        
        return cell
    }    

    func collectionView(collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, atIndexPath indexPath: NSIndexPath) -> UICollectionReusableView {
        
        let reuseIdentifier = (kind == UICollectionElementKindSectionHeader) ? CharacterHeaderFooterResuableViewType.Header.rawValue : CharacterHeaderFooterResuableViewType.Footer.rawValue
        
        let labelPreText = (kind == UICollectionElementKindSectionHeader) ? "Beginning of:" : "End of:"
        
        let labelText = "\(labelPreText) \(sectionTitles[indexPath.row])"
        
        guard let supplementaryView = collectionView.dequeueReusableSupplementaryViewOfKind(kind, withReuseIdentifier: reuseIdentifier, forIndexPath: indexPath) as? CharacterHeaderFooterReusableView else {
            return UICollectionReusableView()
        }
        
        supplementaryView.titleLabel.text = labelText
        
        return supplementaryView
    }
    
}
