//
//  MainViewController.swift
//  NoUnwindTest
//
//  Created by Joe Keeley on 8/8/16.
//  Copyright © 2016 MartianCraft, LLC. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {

    var loggedIn = false
    
    override func viewDidAppear(animated: Bool) {
        if !loggedIn {
            self.performSegueWithIdentifier("showAccountChoice", sender: nil)
        }
    }
    
    @IBAction func unwindWithNewAccount(segue:UIStoryboardSegue) {
        loggedIn = true
    }

    @IBAction func unwindLogin(segue:UIStoryboardSegue) {
        loggedIn = true
    }

}
