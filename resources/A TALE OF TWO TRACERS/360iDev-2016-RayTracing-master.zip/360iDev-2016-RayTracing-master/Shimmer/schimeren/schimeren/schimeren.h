//
//  schimeren.h
//  schimeren
//
//  Created by Jonathan Blocksom on 12/23/14.
//  Copyright (c) 2014 GollyGee Software, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for schimeren.
FOUNDATION_EXPORT double schimerenVersionNumber;

//! Project version string for schimeren.
FOUNDATION_EXPORT const unsigned char schimerenVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <schimeren/PublicHeader.h>


