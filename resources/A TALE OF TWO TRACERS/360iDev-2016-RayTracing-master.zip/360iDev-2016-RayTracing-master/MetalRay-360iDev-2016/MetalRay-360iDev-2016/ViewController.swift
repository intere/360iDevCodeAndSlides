//
//  ViewController.swift
//  MetalRay-360iDev-2016
//
//  Created by Jeff Biggus on 8/19/16.
//  Copyright © 2016 HyperJeff, Inc. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

	override func viewDidLoad() {
		super.viewDidLoad()

		// Do any additional setup after loading the view.
	}

	override var representedObject: Any? {
		didSet {
		// Update the view, if already loaded.
		}
	}


}

