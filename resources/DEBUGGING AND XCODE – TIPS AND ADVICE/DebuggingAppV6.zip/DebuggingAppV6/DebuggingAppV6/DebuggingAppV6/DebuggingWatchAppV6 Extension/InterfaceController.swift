//
//  InterfaceController.swift
//  DebuggingWatchAppV6 Extension
//
//  Created by Kendall Helmstetter Gelner on 8/20/16.
//  Copyright © 2016 KiGi Software, inc. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        WKInterfaceDevice.current().play(.directionUp)

        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        WKInterfaceDevice.current().play(.directionDown)
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
