//
//  WeatherMap.swift
//  DebuggingAppV4
//
//  Created by Kendall Helmstetter Gelner on 8/22/14.
//  Copyright (c) 2014 KiGi Software, LLC. All rights reserved.
//

import Foundation
import UIKit
import CoreLocation
import MapKit

let log = XCGLogger.defaultInstance()

open class WeatherMapVC: UIViewController, CLLocationManagerDelegate {
    
    // Class Var
    var locationManager : CLLocationManager!
    
    var lastLocation : CLLocation?
    
    @IBOutlet weak var mapView: MKMapView?
    @IBOutlet weak var weatherImageView: UIImageView!
    @IBOutlet weak var daySegment: UISegmentedControl!
    
    @IBAction func daySegmentChanged(_ sender: AnyObject) {
    }
    
    // View Controller
    override open func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        locationManager = CLLocationManager()
        setupLocationManager()
    }
    
    override open func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    func setupLocationManager() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        if locationManager.responds(to: #selector(CLLocationManager.requestWhenInUseAuthorization)) {
            locationManager.requestWhenInUseAuthorization()
        } else {
            locationManager.startUpdatingLocation()
        }


    }
    
    // Location Delegate
  open   
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        if let firstLocation : CLLocation = locations.first {

            self.lastLocation = firstLocation
            log.debug() {
                let result = "New location : \(firstLocation)"
                return result
            }
        }
    }
    
    open func locationManager(_ manager: CLLocationManager,
        didChangeAuthorization status: CLAuthorizationStatus)
    {
        switch status {
        case .authorizedAlways, .authorizedWhenInUse:
            print("Allowed: \(status)")
            mapView?.showsUserLocation = true
            locationManager.startUpdatingLocation()
        case .denied:
                locationManager.stopUpdatingLocation()
        default:
            print("State is \(status)")
        }
    }
    
    open static func weatherMapVCFromSB() -> WeatherMapVC? {
        let frameworkBundle = Bundle(identifier: "com.kigisoft.KGWeatherMap")
        let storyboard = UIStoryboard(name: "WeatherMap", bundle: frameworkBundle)
        let vc = storyboard.instantiateViewController(withIdentifier: "WeatherMapVC")
        
        return vc as? WeatherMapVC
    }
}
