//
//  KiGiNetworkingPlAyPI.swift
//  KiGiNetworking
//
//  Created by Kendall Helmstetter Gelner on 2/7/15.
//  Copyright (c) 2015 KiGi Software, LLC. All rights reserved.
//

// This extenstion contains calls useful for playing with the framework in an interactive playground setting

import Foundation

extension WebService {
    
    // Synchronous call so we don't need to add that tricky playground suspension call.
    public func tryJSONServiceCall( _ path:NSString, params:Dictionary<String,String> ) -> Dictionary<String, AnyObject>? {
        var result : Dictionary<String, AnyObject>? = nil

        if let url = buildFullServicePathURL(path as String) {
            // Valid URL
            
            //public func jsonResource<A>(path: String, method: Method, requestParameters: JSONDictionary, parse: JSONDictionary? -> (A?,NSError?) ) -> Resource<A> {

            let resource = jsonResource(path as String, method: Method.GET, requestParameters: params as JSONDictionary, parse: {(retDict:JSONDictionary?) -> (JSONDictionary?, NSError?) in return ( retDict, nil )})
            
            let request = buildRequestFromURL(url, method:resource.useHTTPMethod, headers:resource.headers, parameters:params, paramEncoding:.url)
            
            var response : URLResponse? = nil
            
            do {
                let data : Data = try NSURLConnection.sendSynchronousRequest(request as URLRequest, returning: &response )
                
                //func processServiceCallResult<A>(data:NSData?, response:NSURLResponse?, error:NSError?, resource:Resource<A>, completion: ( resource:Resource<A>, response:NSHTTPURLResponse?, data: NSData?, convertedData:A?,  error:NetworkingFailureReason? ) -> ()) {
                if let useResponse:URLResponse = response  {
                    
                    if let rawResult = processServiceCallResult(data, response: useResponse, error: .none, resource: resource, completion: { (resource, response, data, convertedData, error) -> () in
                        print("Converted Data is \(convertedData)")
                    }) {
                        result = rawResult as Dictionary<String, AnyObject>
                    }
                }
            }
            catch let error1 as NSError {
                print("Error in request : \(error1), response was \(response)")
                if let rawResult = processServiceCallResult(.none, response: response, error: error1, resource: resource, completion: { (resource, response, data, convertedData, error) -> () in
                    print("Converted Data is \(convertedData)")
                }) {
                    result = rawResult as Dictionary<String, AnyObject>
                }

            }
        }
        
        return result
    }
    
   
    public func tryServiceCall( _ path:String, params:Dictionary<String,String> ) -> String? {
        
        print("Trying service call to path '\(path)' for service \(self.name) with params '\(params)'")

        var retVal : String? = nil
        if let url = buildFullServicePathURL(path as String) {
            // Valid URL
            
            print("Got URL \(url)")
            
            //public func jsonResource<A>(path: String, method: Method, requestParameters: JSONDictionary, parse: JSONDictionary? -> (A?,NSError?) ) -> Resource<A> {
            

            let error : NSError? = nil
            
            let parser  = { (data:Data) -> (result: String, parsingError: NSError?) in
                return ( String(data:data, encoding: String.Encoding.utf8) ?? "" , error)
            }
            
            let resource = Resource(path: path as String, useHTTPMethod:Method.GET, headers:[:], parse: parser )
            

            let request = buildRequestFromURL(url, method:resource.useHTTPMethod, headers:resource.headers, parameters:params, paramEncoding:.url)
            
            var response : URLResponse? = nil
            do {
                let data : Data = try NSURLConnection.sendSynchronousRequest(request as URLRequest, returning: &response)
                
                if let useResponse:URLResponse = response  {
                    
                    retVal = processServiceCallResult(data, response: useResponse, error: .none, resource: resource, completion: { (resource, response, data, convertedData, error) -> () in
                        print("Converted Data is \(convertedData)")
                    })
                }
                
            } catch let error1 as NSError {
                retVal = processServiceCallResult(.none, response: response, error: error1, resource: resource, completion: { (resource, response, data, convertedData, error) -> () in
                    print("Converted Data is \(convertedData)")
                })
            }
        }
        
        return retVal
    }

    
}
