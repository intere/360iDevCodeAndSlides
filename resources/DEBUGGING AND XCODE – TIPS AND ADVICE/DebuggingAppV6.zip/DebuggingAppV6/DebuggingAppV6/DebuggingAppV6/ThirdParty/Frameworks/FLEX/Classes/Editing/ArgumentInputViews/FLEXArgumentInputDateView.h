//
//  FLEXArgumentInputDataView.h
//  Flipboard
//
//  Created by Daniel Rodriguez Troitino on 2/14/15.
//  Copyright (c) 2015 Flipboard. All rights reserved.
//

#import "FLEXArgumentInputView.h"

@interface FLEXArgumentInputDateView : FLEXArgumentInputView

@end
