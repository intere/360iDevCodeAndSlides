//
//  KGWeatherMap.h
//  KGWeatherMap
//
//  Created by Kendall Helmstetter Gelner on 8/14/15.
//  Copyright © 2015 KiGi Software, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KGWeatherMap.
FOUNDATION_EXPORT double KGWeatherMapVersionNumber;

//! Project version string for KGWeatherMap.
FOUNDATION_EXPORT const unsigned char KGWeatherMapVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KGWeatherMap/PublicHeader.h>


