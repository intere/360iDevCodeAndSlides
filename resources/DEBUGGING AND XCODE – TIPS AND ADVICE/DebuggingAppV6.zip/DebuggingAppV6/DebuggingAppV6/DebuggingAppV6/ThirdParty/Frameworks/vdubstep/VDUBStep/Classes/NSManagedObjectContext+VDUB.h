//
//  NSManagedObjectContext+VDUB.h
//  VDUBStep
//
//  Copyright (c) 2015 VDUB Software. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface NSManagedObjectContext (VDUB)

- (BOOL)save;

@end
