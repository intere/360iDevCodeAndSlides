//
//  Owner.m
//  UICatalog
//
//  Created by Tim Oliver on 17/02/2016.
//  Copyright © 2016 Realm. All rights reserved.
//

#import "Owner.h"

#if __has_include(<Realm/Realm.h>)

@implementation Owner
@end

#endif