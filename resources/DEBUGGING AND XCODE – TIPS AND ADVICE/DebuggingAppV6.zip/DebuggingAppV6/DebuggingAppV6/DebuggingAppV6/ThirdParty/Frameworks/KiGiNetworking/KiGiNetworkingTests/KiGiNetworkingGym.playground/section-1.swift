// Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


public protocol Holdable
{
    func count1()
    func count2()
}

public struct HolderOfWrappers
{
    let anyWrappedItem: MyResource<Any>
    public init<A>(resource: MyResource<A>) {
        self.anyWrappedItem = MyResource(wrappedItem: resource.wrappedItem, convert: resource.convert)
    }
}

public struct MyResource<A>
{
    let wrappedItem : A
    let convert: String -> A
}

func holdResource<A>( resource: MyResource<A> ) -> HolderOfWrappers
{
    // Error on this line, A is not Any...
    let wrapHolder : HolderOfWrappers = HolderOfWrappers( resource:resource )
    return wrapHolder
}

struct FredThing {
    let name : String
}

func useThing()
{
    let fred = FredThing(name: "OK")
    let useResource = MyResource(wrappedItem: fred, convert: {FredThing(name: $0)})
    let holder = holdResource(useResource)
}

final class Box<T> {
    let unbox: T
    init(_ value: T) { self.unbox = value }
}

enum Result<A> {
    case Success(Box<A>)
    case Failure(NSError)
    
    func flatMap<B>(f:A -> Result<B>) -> Result<B> {
        switch self {
        case Success(let value): return f(value.unbox)
        case Failure(let error): return .Failure(error)
        }
    }
}


infix operator >>-> {}
func >>-> <T,U>(x: Result<T>, f:T -> Result<U>) -> Result<U> {
    return x.flatMap(f)
}

var AssociatedObjectHandle: UInt8 = 0

extension Optional {
    var error : AnyObject? {
        get { return self.wrappedError() }
    }
    
    private func selfAddress() -> String
    {
        let objAddressVal = unsafeBitCast(self, Int.self)
        return NSString(format: "%x", objAddressVal)
    }
    
    private func wrappedError() -> AnyObject? {
        
        return objc_getAssociatedObject(self.selfAddress(), &AssociatedObjectHandle)
    }
    
    static func nilOptionalWithError(error:AnyObject)
    {
        //let
        //objc_setAssociatedObject(target, ptr, object, UInt(OBJC_ASSOCIATION_RETAIN_NONATOMIC))
    }
}

var hello = "Hello!"

//func linq25(){
//    let numbers = [ 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 ]
//    
//    var index = 0
//    let firstSmallNumbers = numbers.takeWhile { $0 >= index++ }
//    
//    println("First numbers not less than their position:")
//    firstSmallNumbers.each(println)
//}


struct Fred : NilLiteralConvertible {
    let fredMessage:String?
    init(nilLiteral: ()) {
        fredMessage = "fred"
    }
}


var one : Optional<String>

one = Optional(Fred("Jim"))

if one == nil {
    println("one is nil")
} else {
    println("one is not nil")
}


