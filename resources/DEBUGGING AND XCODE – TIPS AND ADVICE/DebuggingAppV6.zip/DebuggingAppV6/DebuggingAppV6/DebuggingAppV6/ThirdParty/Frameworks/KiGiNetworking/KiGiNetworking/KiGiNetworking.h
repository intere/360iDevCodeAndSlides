//
//  KiGiNetworking.h
//  KiGiNetworking
//
//  Created by Kendall Helmstetter Gelner on 2/2/15.
//  Copyright (c) 2015 KiGi Software, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KiGiNetworking.
FOUNDATION_EXPORT double KiGiNetworkingVersionNumber;

//! Project version string for KiGiNetworking.
FOUNDATION_EXPORT const unsigned char KiGiNetworkingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KiGiNetworking/PublicHeader.h>

