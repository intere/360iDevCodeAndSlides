//
//  FLEXLibrariesTableViewController.h
//  Flipboard
//
//  Created by Ryan Olson on 2014-05-02.
//  Copyright (c) 2014 Flipboard. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FLEXLibrariesTableViewController : UITableViewController

@end
