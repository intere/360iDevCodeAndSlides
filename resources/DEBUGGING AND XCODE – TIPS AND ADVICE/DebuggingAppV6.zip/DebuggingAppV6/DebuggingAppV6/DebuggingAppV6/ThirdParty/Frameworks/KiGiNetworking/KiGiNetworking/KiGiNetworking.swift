//
//  KiGiNetworking.swift
//  KiGiNetworking
//
//  Created by Kendall Helmstetter Gelner on 2/2/15.
//  Copyright (c) 2015 KiGi Software, LLC. All rights reserved.
//

// Based on a micture of AlamoFire:
// 
//  https://github.com/Alamofire/Alamofire
//  And networking code from this talk:
//
// Plus a lot of my own changes

import Foundation


// Taken mostly from https://gist.github.com/chriseidhof/26bda788f13b3e8a279c


public enum Protocol: String {
    case HTTP = "http"
    case HTTPS = "https"
}

public enum Method: String { // Bluntly stolen from Alamofire
    case OPTIONS = "OPTIONS"
    case GET = "GET"
    case HEAD = "HEAD"
    case POST = "POST"
    case PUT = "PUT"
    case PATCH = "PATCH"
    case DELETE = "DELETE"
    case TRACE = "TRACE"
    case CONNECT = "CONNECT"
}

public enum ParameterEncoding {
    /**
    A query string to be set to URL for `GET`, `HEAD`, and `DELETE` reuquest HTTPMethod, FORM for any other type.
    */
    case auto
    
    /** 
    Pass parameters in URL.
    */
    case url
  
    /**
    Pass parameters in body using standard HTTP form.
    */
    case form
    
    /**
    Uses `NSJSONSerialization` to create a JSON representation of the parameters object, which is set as the body of the request. The `Content-Type` HTTP header field of an encoded request is set to `application/json`.
    */
    case json
    
    /**
    Uses `NSPropertyListSerialization` to create a plist representation of the parameters object, according to the associated format and write options values, which is set as the body of the request. The `Content-Type` HTTP header field of an encoded request is set to `application/x-plist`.
    */
    case propertyList(PropertyListSerialization.PropertyListFormat, PropertyListSerialization.WriteOptions)
    
    func encodeParameters( _ parameters:[String:String], request:NSMutableURLRequest )
    {
        if parameters.count == 0 {
            // No work needs to be done if paramaters do not exist!
            return
        }
        
        let method = request.httpMethod
        
        switch self {
        case .auto:
            // ==Figure out what encoding we should default to and return that
            switch method {
            case Method.GET.rawValue, Method.HEAD.rawValue, Method.DELETE.rawValue:
                return ParameterEncoding.url.encodeParameters(parameters, request:request)
            default:
                return  ParameterEncoding.form.encodeParameters(parameters, request:request)
            }
        case .url:
            // ==Need to place params in URL
            let queryArray = parameters.keys.map({URLQueryItem(name: $0, value:(parameters[$0] ?? ""))})
            // Add in params to query string
            if let existignURL = request.url {
                if var existingURLComponents = URLComponents(url: existignURL, resolvingAgainstBaseURL: false) {
                    var useQueryItems : [URLQueryItem] = []
                    if let currentQueryItems = existingURLComponents.queryItems.flatMap({return $0}) {
                        // Since there are already query items, preserve them
                        useQueryItems += currentQueryItems
                    }
                    useQueryItems += queryArray
                    existingURLComponents.queryItems = useQueryItems
                    // Reassign URL, now with added query components.
                    request.url = existingURLComponents.url
                } else {
                    // Error: could not build URL components from held URL, so we have nothing to attach query params to.
                }
            } else {
                // Error: Request does not contain a URL!
            }
            
        case .form:
            // Place parameters in body
            let postString = {($0 ?? "")}
            let queryArray = parameters.keys.map({"\(postString($0))=\(postString(parameters[$0]))"})
            let flattenParams = queryArray.joined(separator:"&")
            request.httpBody = flattenParams.data(using: String.Encoding.utf8)
            request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
            
            
        case .json:
            // Params as property list encoded in body
            if let jsonData = encodeJSON(parameters) {
                request.httpBody = jsonData
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            }

        case .propertyList(let (format, options)):
            // Params as property list encoded in body
            let converted : Any = parameters
            do {
                let plistData : Data = try PropertyListSerialization.data(fromPropertyList: converted, format: format, options: options)
                request.httpBody = plistData
                request.setValue("application/x-plist", forHTTPHeaderField: "Content-Type")
            } catch let error1 as NSError {
                print("Error: \(error1)")
            }
        }
    }
}

public struct WebServiceTask
{
    let service: WebService
    let resource: Resource<Any>
    let task: URLSessionDataTask?
    public init<A>( service: WebService, resource:Resource<A>, task: URLSessionDataTask?) {
        self.service = service
        self.task = task
        
        let parser = { (data:Data) -> (result:A?, parsingError:NSError?) in
            
            let parseResult : (A?, NSError?) = resource.parse(data)
                
                return  parseResult
            }
        
        // This crazy code is the only way to set the resource object that should take any type
        self.resource = Resource(path: resource.path, useHTTPMethod: resource.useHTTPMethod, headers: resource.headers, parse: parser )
       
    }
}



public struct WebService
{
    public let name: String
    public let host: String
    public let commProtocol: Protocol
    
    public init ( name:String, host:String, commProtocol:Protocol) {
        self.name = name
        self.host = host
        self.commProtocol = commProtocol
        self.session = URLSession.shared
    }
    
    public func buildFullServicePathURL( _ relativePath:String ) -> URL? {
        let baseURL = self.baseURL()
        print("Got base URL \(baseURL)")
        if let url = baseURL?.appendingPathComponent(relativePath) {
            return url;
        } else {
            return nil;
        }
    }
    
    public func baseURL() -> URL?
    {
        let baseURLString = "\(self.commProtocol.rawValue)://\(self.host)"
        let baseURL = URL(string: baseURLString)
        return baseURL
    }
    
    let session : URLSession
    
    func buildRequestFromURL(_ url:URL, method:Method, headers:[String:String], parameters:[String:String], paramEncoding:ParameterEncoding = .auto) -> NSMutableURLRequest {
        
        let request = NSMutableURLRequest(url: url)
        request.httpMethod = method.rawValue
        for (key,value) in headers {
            request.setValue(value, forHTTPHeaderField: key)
        }
        paramEncoding.encodeParameters(parameters, request:request)
        
        print("Built service request : \(request)")
        
        return request
    }
    
    /**
    This call processes the service call API Request result.  It's normally called by apiRequest, but exists seperated so that non-async calls can be made and processed.
    */
    func processServiceCallResult<A>(_ data:Data?, response:URLResponse?, error:Error?, resource:Resource<A>, completion: ( _ resource:Resource<A>, _ response:HTTPURLResponse?, _ data: Data?, _ convertedData:A?,  _ error:NetworkingFailureReason? ) -> ()) -> A? {
        
        var retVal : A? = nil
            if let httpResponse = response as? HTTPURLResponse {
                if httpResponse.statusCode == 200 {
                    if let responseData = data {
                        let parseResult = resource.parse(responseData)
                        if  parseResult.result != nil {
                            print("Response was \(parseResult)")
                            completion(resource, httpResponse, responseData, parseResult.result,  .none)
                            retVal = parseResult.result
                        } else {
                            print("Could not parse \(responseData)")
                            completion( resource, httpResponse, responseData, .none,  .couldNotParseJSON(parseResult.parsingError))
                        }
                    } else {
                        print("Networking failure \(data)")
                        completion( resource, httpResponse, .none, .none,  .noData)
                    }
                } else {
                    if ( httpResponse.statusCode < 500 || httpResponse.statusCode > 599 ) {
                        print("Networking failure no success \(httpResponse.statusCode)")
                        completion( resource, httpResponse, .none, .none,  NetworkingFailureReason.networkFailureStatusCode(statusCode: httpResponse.statusCode))
                    }
                    else {
                        var serverMessage : String? = nil
                        var responseData : Data? = nil
                        if let data = data {
                            responseData = data
                            serverMessage = String(data:data, encoding: String.Encoding.utf8)
                        }
                        print("Server failure \(httpResponse.statusCode)")
                        completion( resource, httpResponse, responseData, .none,  NetworkingFailureReason.serverFailureStatusCode(statusCode: httpResponse.statusCode, serverMessage:serverMessage))
                    }
                }
            } else {
                print("Networking errror \(error)")
                let useResource : Resource<A> = Resource(path: resource.path, useHTTPMethod: resource.useHTTPMethod, headers: resource.headers, parse: resource.parse)
                let useFailureReason : NetworkingFailureReason = error != nil ? .other(error!) : .generalCallFailure
                if let falseData : Data = "".data(using: String.Encoding.utf8, allowLossyConversion: true) {
                    // Have to insert fake NSData or compiler crash is result!!!
                    completion( useResource, nil , falseData, .none, useFailureReason )
                }
            }
        return retVal;
    }
    
    
    /**
    Specilaized variant of request call just for images.
    */
    public func apiImageRequest( _ imageURL: String, completion: @escaping ( _ resource:Resource<UIImage>, _ response:HTTPURLResponse?, _ data: Data?, _ convertedData:UIImage?,  _ error:NetworkingFailureReason? ) -> ()) -> WebServiceTask
    {
        let resource = imageResource(imageURL, parameters: [:])
        if let imageURL = URL(string: imageURL) {
        // Adds just one of the default params so we call the master method
            let request = buildRequestFromURL(imageURL, method:resource.useHTTPMethod, headers:resource.headers, parameters:[:], paramEncoding: .auto)
            let task = session.dataTask(with: request as URLRequest) { (data, response, error) -> Void in
                _ = self.processServiceCallResult(data, response:response, error:error, resource:resource, completion:completion)
            }
            task.resume()
            let serviceTask = WebServiceTask(service: self, resource: resource, task: task)
            
            return serviceTask
        }
        
        //  If it did not make it through previous code, we must have a bad URL - flag and error out
        let errorReason : NetworkingFailureReason = .badURL
        completion( resource, .none, .none, .none,  errorReason)
        
        let serviceTaskError = gernericNetworkignFailureWebTask(resource)
        return serviceTaskError
    }
    
    /** 
    Simpler form of main apiRequest call that exists so auto-completion does not look so imposing.
    */
    public func apiRequest<A>( _ resource: Resource<A>, parameters:[String:String], completion: @escaping ( _ resource:Resource<A>, _ response:HTTPURLResponse?, _ data: Data?, _ convertedData:A?,  _ error:NetworkingFailureReason? ) -> ()) -> WebServiceTask
    {
        
        let result = self.apiRequest(resource, parameters: parameters, paramEncoding: .auto, completion: completion)
        return result
    }
    
    func gernericNetworkignFailureWebTask<A>(_ resource: Resource<A>) -> WebServiceTask
    {
        //  If it did not make it through previous code, we must have a bad URL - flag and error out
        //let errorReason : NetworkingFailureReason = .BadURL
        let serviceTask = WebServiceTask(service: self, resource: resource, task: nil)
        return serviceTask
    }
    
    /**
    Creates a web service task whcih starts executing immediatley.  You can control the task through the 
    */
    public func apiRequest<A>( _ resource: Resource<A>, parameters:[String:String], paramEncoding : ParameterEncoding, requestBody:Data? = nil, modifyRequest: (NSMutableURLRequest)->() = {(NSMutableURLRequest)->() in}, completion: @escaping ( _ resource:Resource<A>, _ response:HTTPURLResponse?, _ data: Data?, _ convertedData:A?,  _ error:NetworkingFailureReason? ) -> ()) -> WebServiceTask
    {
        if let baseURL = self.baseURL() {
            if let _ = buildFullServicePathURL(resource.path) {
                let request = buildRequestFromURL(baseURL, method:resource.useHTTPMethod, headers:resource.headers, parameters:parameters, paramEncoding:paramEncoding)
                if requestBody != nil {
                    request.httpBody = requestBody
                }
                // Any passed in further HTTP modificatons handled here
                modifyRequest(request)
                let task = session.dataTask(with: request as URLRequest, completionHandler: { (data:Data?, response:URLResponse?, error:Error?) in
                     _ = self.processServiceCallResult(data, response:response, error:error, resource:resource, completion:completion)
                })
               
                task.resume()
                let serviceTask = WebServiceTask(service: self, resource: resource, task: task)
                
                return serviceTask
                
            }
        }

        //  If it did not make it through previous code, we must have a bad URL - flag and error out
        let errorReason : NetworkingFailureReason = .badURL
        completion( resource, .none, .none, .none,  errorReason)
        
        let serviceTaskError = gernericNetworkignFailureWebTask(resource)
        return serviceTaskError
    }
}





public struct Resource<A> {
    public let path: String
    public let useHTTPMethod : Method
    public let headers : [String:String]
    public let parse: (Data) -> (result:A?, parsingError:NSError?)
//    public init( path:String, method:Method, headers:[String:String], parse:NSData->(A?, NSError?)) {
//        self.path = path
//        self.useHTTPMethod = method
//        self.headers = headers
//        self.parse = parse
//    }
}

public enum NetworkingFailureReason {
    case badURL
    case couldNotParseJSON(NSError?)
    case noData
    case serverFailureStatusCode(statusCode: Int, serverMessage:String?)
    case networkFailureStatusCode(statusCode: Int)
    case other(Error)
    case generalCallFailure
}



// Here are some convenience functions for dealing with JSON APIs

public typealias JSONDictionary = [String:Any]

func decodeJSON(_ data: Data) -> (resultDict:JSONDictionary?, error:NSError?) {
    var error : NSError? = nil
    let parseResult : Any?
    do {
        parseResult = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions())
    } catch let error1 as NSError {
        error = error1
        parseResult = nil
    }
    if let parseResultDictionary = parseResult as? [String:AnyObject] {
        return (parseResultDictionary, error)
    } else if let parseResult : Any = parseResult {
        // Embed whatever it is inside of a dictionary so return type is maintained
        let wrapDict = ["result":parseResult]
        return (wrapDict, error)
    }
    return (nil, error)
}

func encodeJSON(_ dict: JSONDictionary) -> Data? {
    return dict.count > 0 ? try! JSONSerialization.data(withJSONObject: dict, options: JSONSerialization.WritingOptions()) : nil
}

public func jsonResource<A>(_ path: String, method: Method, requestParameters: JSONDictionary, parse: @escaping (JSONDictionary?) -> (A?,NSError?) ) -> Resource<A> {
    let f : (Data) -> (result:A?, parsingError:NSError?) = {
        let decodeResult = decodeJSON($0)
        if  let result = decodeResult.resultDict {
            return parse(result)
        } else {
            return (.none, decodeResult.error)
        }
    }
    
    //let jsonBody = encodeJSON(requestParameters)
    let headers = ["Content-Type": "application/json"]
    return Resource(path: path, useHTTPMethod: method, headers: headers, parse:f)
}

public func nullResource() -> Resource<String> {    
    return Resource(path: "", useHTTPMethod: .GET, headers:[:], parse:{ (data : Data) -> (result:String?, parsingError:NSError?) in return (.none,.none)})
}


public func imageResource(_ path: String, parameters: JSONDictionary ) -> Resource<UIImage> {
    let f : (Data) -> (result:UIImage?, parsingError:NSError?) = {
        if let decodeResult = UIImage(data: $0) {
            return (decodeResult, .none)
        } else {
            return (.none, NSError(domain: "UIImageDecode", code:42, userInfo: ["data":$0]))
        }
    }
    
    //let jsonBody = encodeJSON(parameters)
    let headers = ["Content-Type": "application/json"]
    return Resource(path: path, useHTTPMethod: .GET, headers: headers, parse:f)
}


