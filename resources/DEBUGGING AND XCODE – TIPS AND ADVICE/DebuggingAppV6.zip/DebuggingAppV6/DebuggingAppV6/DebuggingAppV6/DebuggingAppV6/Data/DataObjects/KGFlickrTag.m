#import "KGFlickrTag.h"

#import <VDUBStep/VDUBStep.h>

@implementation KGFlickrTag

// Custom logic goes here.
+ (KGFlickrTag * ) createFlickrTag
{
    return [self createInContext:[VDUBStore mainContext]];
}

@end
