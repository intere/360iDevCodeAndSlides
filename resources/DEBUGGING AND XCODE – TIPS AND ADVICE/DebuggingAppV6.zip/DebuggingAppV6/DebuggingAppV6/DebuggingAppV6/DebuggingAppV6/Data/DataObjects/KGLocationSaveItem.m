#import "KGLocationSaveItem.h"

@implementation KGLocationSaveItem

// Custom logic goes here.

@end
