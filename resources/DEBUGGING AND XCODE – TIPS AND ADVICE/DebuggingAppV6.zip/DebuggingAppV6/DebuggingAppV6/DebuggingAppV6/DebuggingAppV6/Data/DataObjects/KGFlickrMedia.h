#import "_KGFlickrMedia.h"

@interface KGFlickrMedia : _KGFlickrMedia {}
// Custom logic goes here.

+ (KGFlickrMedia * ) createFlickrMedia;

@end
