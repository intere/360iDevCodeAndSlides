#import "KGFlickrMedia.h"

#import <VDUBStep/VDUBStep.h>

@implementation KGFlickrMedia

// Custom logic goes here.
+ (KGFlickrMedia * ) createFlickrMedia
{
    return [self createInContext:[VDUBStore mainContext]];
}

@end
