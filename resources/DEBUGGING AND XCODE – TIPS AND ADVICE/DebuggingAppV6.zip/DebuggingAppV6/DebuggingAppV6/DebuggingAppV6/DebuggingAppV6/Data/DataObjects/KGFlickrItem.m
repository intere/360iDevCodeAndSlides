#import "KGFlickrItem.h"
#import <VDUBStep/VDUBStep.h>

@implementation KGFlickrItem

// Custom logic goes here.

+ (KGFlickrItem * ) createFlickrItem
{
    return [self createInContext:[VDUBStore mainContext]];
}

+ (void) clearAllItems
{
    NSArray *allItems = [self findAllInContext:[VDUBStore mainContext]];
    for ( NSManagedObject * item in allItems )
    {
        [item delete];
    }
    
    [[VDUBStore mainContext] save];
}

+ (void) saveAllModfiedFlickrItems
{
    NSManagedObjectContext *context = [VDUBStore mainContext];
    NSError *error = nil;
    @try {
        [context save:&error];
    }
    @catch (NSException *exception) {
        NSLog(@"Crash in saving new photos! %@", [exception userInfo]);
    }
    @finally {
    }
    if ( error )
    {
        NSLog(@"Error saving flickr items: %@", error);
    }
}


+ (NSFetchedResultsController *)fetchedResultsControllerForFlckrItems
{
    
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:[self entityName]];
    request.sortDescriptors = @[[NSSortDescriptor sortDescriptorWithKey:@"published" ascending:YES]];
    
    [request setFetchBatchSize:20];
    
    NSFetchedResultsController *theFetchedResultsController =
    [[NSFetchedResultsController alloc] initWithFetchRequest:request
                                        managedObjectContext:[VDUBStore mainContext] sectionNameKeyPath:nil
                                                   cacheName:@"FlickrRoot"];

    
    return theFetchedResultsController;
}

+ (NSArray *)allFlickrItems;
{
    return [self findAllInContext:[VDUBStore mainContext]];
}


@end
