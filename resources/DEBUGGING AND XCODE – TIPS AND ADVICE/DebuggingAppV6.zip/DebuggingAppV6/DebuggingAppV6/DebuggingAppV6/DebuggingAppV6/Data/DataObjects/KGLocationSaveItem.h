#import "_KGLocationSaveItem.h"

@interface KGLocationSaveItem : _KGLocationSaveItem {}
// Custom logic goes here.
@end
