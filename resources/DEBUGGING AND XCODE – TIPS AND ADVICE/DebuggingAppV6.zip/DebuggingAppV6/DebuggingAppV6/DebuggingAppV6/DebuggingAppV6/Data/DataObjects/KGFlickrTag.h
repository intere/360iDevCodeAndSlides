#import "_KGFlickrTag.h"

@interface KGFlickrTag : _KGFlickrTag {}
// Custom logic goes here.

+ (KGFlickrTag * ) createFlickrTag;

@end
