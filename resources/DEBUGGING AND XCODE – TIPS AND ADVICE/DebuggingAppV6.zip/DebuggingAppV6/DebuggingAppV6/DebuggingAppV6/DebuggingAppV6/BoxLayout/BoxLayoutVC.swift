//
//  BoxLayoutVC.swift
//  DebuggingAppV4
//
//  Created by Kendall Helmstetter Gelner on 8/22/14.
//  Copyright (c) 2014 KiGi Software, LLC. All rights reserved.
//

import Foundation

//import FLEX
import UIKit

class BoxLayoutVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        //FLEXManager.shared().showExplorer()
        
    }
    
    private func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return 10;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        print("Current row is \(indexPath)")
        let cell: UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "NADACELL", for: indexPath)
        return cell
    }
    
}
