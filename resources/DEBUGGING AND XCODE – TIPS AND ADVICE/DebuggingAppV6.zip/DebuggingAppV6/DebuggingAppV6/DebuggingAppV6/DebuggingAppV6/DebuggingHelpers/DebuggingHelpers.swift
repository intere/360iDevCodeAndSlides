//
//  DebuggingHelpers.swift
//  DebuggingAppV5
//
//  Created by Kendall Helmstetter Gelner on 2/2/15.
//  Copyright © 2015 KiGi Software, Inc. All rights reserved.
//

import Foundation
import CoreData

extension NSIndexPath
{
    override open var debugDescription: String {
        get {
            return "Row:\(self.row) Sec:\(self.section)"
        }}
}

extension NSManagedObject
{
    func dumpProperties()
    {
        for (key, _) in entity.propertiesByName as [String : AnyObject] {
            print("\"\(key)\": \(value(forKey: key))")
        }
    }
}
