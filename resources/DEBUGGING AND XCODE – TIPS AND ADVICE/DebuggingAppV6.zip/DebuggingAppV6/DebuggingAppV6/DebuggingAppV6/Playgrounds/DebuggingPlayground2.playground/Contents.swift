//: Playground - noun: a place where people can play

import UIKit
import XCPlayground
import KGWeatherMap
import MapKit
import PlaygroundSupport

let myWeatherVC = WeatherMapVC.weatherMapVCFromSB()

let weatherView = myWeatherVC?.view

PlaygroundPage.current.liveView = myWeatherVC

//XCPShowView("Map", view: (myWeatherVC?.view)! )





//XCPSetExecutionShouldContinueIndefinitely(true)



